<?php

interface IWPML_TM_Word_Count_Set {

	public function process( $id );
}