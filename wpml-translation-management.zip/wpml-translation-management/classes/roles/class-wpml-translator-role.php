<?php

class WPML_Translator_Role {
	const CAPABILITY = 'translate';

}