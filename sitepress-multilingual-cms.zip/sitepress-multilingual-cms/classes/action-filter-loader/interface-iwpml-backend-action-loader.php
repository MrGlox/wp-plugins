<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_Backend_Action_Loader extends IWPML_Action_Loader_Factory {

}
